import 'package:flutter/material.dart';
import 'package:ranking_futebol/unitglob.dart' as unitglob;

class PontosFrame extends StatelessWidget {
  final Map item;
  final Function(String texto) funcao;
  final int? index;
  PontosFrame({
    Key? key,
    required this.item,
    required this.funcao,
    this.index,
  }) : super(key: key);

  List<String> lista2 = [];

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Visibility(
          visible: unitglob.visivel,
          child: Container(
            color: Colors.blue.shade100,
            child: Text(
              item['pon_ano'] != null ? item['pon_ano'].toString() : 'pon_ano',
              textAlign: TextAlign.center,
              style: const TextStyle(
                fontSize: 20.0,
                color: Colors.black,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ),
        Visibility(
          //visible: texto != "" ? true : false,
          visible: ((unitglob.opcnum) == 1 ||
                  (unitglob.opcnum) == 20 ||
                  ((unitglob.opcnum) == 32) && (item['pon_grupo'] != null)) &&
              (unitglob.antgrupo == '' ||
                  item['pon_grupo'] != unitglob.antgrupo),
          child: Container(
              color: Colors.yellow.shade100,
              child: item['pon_grupo'] != null
                  ? Text(
                      grupo(item['pon_grupo']), //texto!,
                      textAlign: TextAlign.center,
                      style: const TextStyle(
                        fontSize: 17.0,
                        color: Colors.redAccent,
                        fontWeight: FontWeight.bold,
                      ),
                    )
                  : const SizedBox()),
        ),
        Visibility(
          visible: (unitglob.opcnum == 32),
          child: Container(
              color: Colors.yellow.shade100,
              child: item['tor_descri'] != null
                  ? Text(
                      item['tor_descri'],
                      textAlign: TextAlign.center,
                      style: const TextStyle(
                        fontSize: 20.0,
                        color: Colors.redAccent,
                        fontWeight: FontWeight.bold,
                      ),
                    )
                  : const SizedBox()),
        ),
        Container(
          color: Colors.yellow.shade200,
          child: Text(
            item['clu_nome'] == null
                ? '${index.toString()}º ${item['est_estado']}'
                : //'pon_ano',
                /*(unitglob.numreg == unitglob.maximo
                        ? lista2[index]
                        : classif(item['pon_classi'] == null
                            ? unitglob.numreg
                            : item['pon_classi'])) +*/
                (unitglob.opcnum != 9
                        ? item['pon_classi'] == null
                            ? ''
                            : '${item['pon_classi']}º '
                        : '${index.toString()}º ') +
                    '${item['clu_nome']} / ${item['clu_cidade']} / ' +
                    item['est_estado'] +
                    (unitglob.opcnum != 21
                        ? ''
                        : ' (${item['pon_classi']}º em ${item['pon_ano']})'),
            textAlign: TextAlign.center,
            style: const TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.only(left: 3, right: 8),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Visibility(
                visible: unitglob.mostrafig,
                child: Expanded(
                  flex: 1,
                  child: Center(
                      child: Image.network(
                    item['clu_ordem'] == null
                        ? '${unitglob.fotos}est_${item['''clu_estado''']}.jpg'
                        : '${unitglob.fotos}cl${item['''clu_ordem''']}.jpg',
                    width: 40,
                    height: 40,
                  )),
                ),
              ),
              Expanded(
                flex: 5,
                child: Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Texto(
                          titulo: 'Pontos',
                          value: item['pon_pontos'].toString(),
                          funcao: () => funcao('Pontos'),
                          //inMarcado: item['marcado'],
                        ),
                        Texto(
                          titulo: 'Jogos',
                          value: item['pon_jogos'].toString(),
                          funcao: () => funcao('Jogos'),
                          //inMarcado: item['marcado'],
                        ),
                        Texto(
                          titulo: 'Vitórias',
                          value: item['pon_vitori'].toString(),
                          funcao: () => funcao('Vitórias'),
                          //inMarcado: item['marcado'],
                        ),
                        Texto(
                          titulo: 'Empates',
                          value: item['pon_empate'].toString(),
                          //inMarcado: item['marcado'],
                        ),
                        Texto(
                          titulo: 'Derrotas',
                          value: item['pon_derrot'].toString(),
                          //inMarcado: item['marcado'],
                        ),
                      ],
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Texto(
                          titulo: 'Gols Pró',
                          value: item['pon_golpro'].toString(),
                          funcao: () => funcao('Gols'),
                          //inMarcado: item['marcado'],
                        ),
                        Texto(
                          titulo: 'Gols Contra',
                          value: item['pon_golcon'].toString(),
                          //inMarcado: item['marcado'],
                        ),
                        Texto(
                          titulo: 'Saldo',
                          value: item['pon_saldo'].toString(),
                          funcao: () => funcao('Saldo'),
                          //inMarcado: item['marcado'],
                        ),
                        Texto(
                          titulo: 'Aproveit',
                          value: '${item['pon_aprove']}%',
                          funcao: () => funcao('Aprov'),
                          //inMarcado: item['marcado'],
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        Visibility(
          visible: item['pon_artilh'] != null,
          child: Text(
            item['pon_artilh'] != null
                ? "Artilheiro(s): ${item['pon_artilh']}"
                : 'pon_artilh',
            //}
            textAlign: TextAlign.center,
            style: const TextStyle(
              fontSize: 16.0,
              //color: Colors.black,
            ),
          ),
        ),
        Visibility(
          visible: item['pon_observ'] != null,
          child: Container(
              //color: Colors.yellow.shade100,

              child: item['pon_observ'] != null
                  ? Text(
                      item['pon_observ'] != null
                          ? "Obs: ${item['pon_observ']}"
                          : 'pon_observ',
                      textAlign: TextAlign.center,
                      style: const TextStyle(
                        fontSize: 16.0,
                        //color: Colors.redAccent,
                        //fontWeight: FontWeight.bold,
                      ),
                    )
                  : const SizedBox()),
        ),
      ],
    );
  }

  String classif(int classi) {
    unitglob.numreg++;
    String resulta = '';
    if ((unitglob.opcnum == 1) ||
        (unitglob.opcnum == 20) &&
            (int.parse(unitglob.ano1) == int.parse(unitglob.ano2))) {
      if (int.parse(unitglob.ano1) <= int.parse(unitglob.anomax)) {
        resulta = '$classiº ';
        //}  else {}
      } else {
        resulta = '';
      }
    } else if ((unitglob.opcnum == 23 || unitglob.opcnum == 24)) {
      resulta = '$classiº ';
    } else if (unitglob.opcnum != 9) {
      resulta = (unitglob.numreg).toString() + 'º '; // '$classiº '; //
    } else {
      resulta = '';
    }
    lista2[unitglob.numreg] = resulta;
    return resulta;
  }

  String grupo(String grup) {
    unitglob.antgrupo = grup;
    return grup;
  }
}

//Montei um widget padrão, para ter um texto em cima do outro
//além da opção de clique
class Texto extends StatelessWidget {
  final String titulo;
  final String value;
  final Function()? funcao;
  final bool inMarcado;
  const Texto({
    Key? key,
    required this.titulo,
    required this.value,
    this.funcao,
    this.inMarcado = false,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.all(0),
      decoration: inMarcado
          ? BoxDecoration(
              borderRadius: BorderRadius.circular(5),
              color: Colors.green,
              border: Border.all(),
            )
          : null,
      child: InkWell(
        onTap: funcao ?? funcao,
        child: Column(
          children: [
            Text(titulo),
            Text(value,
                style: const TextStyle(
                  fontSize: 16.0,
                  color: Colors.green,
                  fontWeight: FontWeight.bold,
                )),
          ],
        ),
      ),
    );
  }
}
