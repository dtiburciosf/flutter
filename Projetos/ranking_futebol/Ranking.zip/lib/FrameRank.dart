import 'package:flutter/material.dart';
import 'package:ranking_futebol/unitglob.dart' as unitglob;

class RankingFrame extends StatelessWidget {
  final Map item;
  final int? index;
  const RankingFrame({
    Key? key,
    required this.item,
    this.index,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Column(children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Center(
                  child: Visibility(
                    visible: unitglob.opcnum == 32
                        ? true
                        : (item['pon_ano'] != null ? true : false) &&
                            (unitglob.opcnum == 13 ||
                                unitglob.opcnum == 14 ||
                                unitglob.opcnum == 32),
                    child: Text(
                      unitglob.opcnum == 32
                          ? item['clu_ano'].toString()
                          : item['pon_ano'].toString(),
                      textAlign: TextAlign.center,
                      style: const TextStyle(
                          fontSize: 20.0,
                          decoration: TextDecoration.underline,
                          fontWeight: FontWeight.bold
                          //color: Colors.black,
                          ),
                    ),
                  ),
                ),
              ],
            ),
          ]),
        ],
      ),
      Padding(
        padding: const EdgeInsets.only(left: 3, right: 8),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          crossAxisAlignment: CrossAxisAlignment.center,
          /*children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            crossAxisAlignment: CrossAxisAlignment.center,*/
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Visibility(
                  visible: unitglob.mostrafig,
                  child: Expanded(
                      flex: 1,
                      child: Center(
                          child: Image.network(
                        (unitglob.opcnum != 11 && unitglob.opcnum != 22)
                            ? '${'${unitglob.fotos}cl${item['clu_ordem'].toString()}'}.jpg'
                            : '${'${unitglob.fotos}est_${item['est_pais'].toString()}'}.jpg',
                        width: 40,
                        height: 40,
                      ))),
                ),
              ],
            ),
          ],
          //),
          //],
        ),
        //],
      ),
      Column(
        //children: Row(

        children: [
          Text(
            (unitglob.opcnum == 11 || unitglob.opcnum == 22)
                ? item['est_estado'].toString()
                : (unitglob.opcnum == 14 || unitglob.opcnum == 15)
                    ? item['pon_artilh'].toString()
                    : item['clu_nome'] +
                        ' / ' +
                        item['clu_cidade'] +
                        ' / ' +
                        item['est_estado'],
            textAlign: TextAlign.center,
            style: const TextStyle(
                fontSize: 20.0,
                decoration: TextDecoration.underline,
                fontWeight: FontWeight.bold
                //color: Colors.black,
                ),
          ),
          Text(
            unitglob.opcnum == 8
                ? '${item['pon_classi']} ponto(s)'
                : unitglob.opcnum == 11 || unitglob.opcnum == 12
                    ? item['pon_titulo'].toString()
                    : unitglob.opcnum == 10 ||
                            unitglob.opcnum == 25 ||
                            unitglob.opcnum == 26
                        ? '${item['pon_titulo']}: ' + item['anos']
                        : unitglob.opcnum == 22
                            ? item['num'].toString()
                            : unitglob.opcnum == 13
                                ? '${item['pon_classi']}º lugar'
                                : unitglob.opcnum == 14
                                    ? item['clu_nome'] +
                                        ' / ' +
                                        item['clu_cidade'] +
                                        ' / ' +
                                        item['est_estado']
                                    : unitglob.opcnum == 32
                                        ? item['clu_estadi'] != null
                                            ? 'Estádio: ' + item['clu_estadi']
                                            : ''
                                        : item['pon_ano'].toString(),
            textAlign: TextAlign.center,
            style: const TextStyle(
              fontSize: 20.0,
              //decoration: TextDecoration.underline,
              //fontWeight: FontWeight.bold
              color: Color(0xFF009688), // Colors.green,
            ),
          ),
        ],
      ),
    ]);
  }
}
