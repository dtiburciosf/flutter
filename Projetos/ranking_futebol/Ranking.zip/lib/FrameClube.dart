import 'package:flutter/material.dart';
import 'package:ranking_futebol/unitglob.dart' as unitglob;
import 'package:http/http.dart' as http;
import 'dart:convert';

class ClubeFrame extends StatelessWidget {
  final Map item;
  final int? index;
  const ClubeFrame({
    Key? key,
    required this.item,
    this.index,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Text(
          item['pon_ano'].toString(),
          textAlign: TextAlign.center,
          style: const TextStyle(
              fontSize: 20.0,
              decoration: TextDecoration.underline,
              fontWeight: FontWeight.bold
              //color: Colors.black,
              ),
        ),
        Padding(
          padding: const EdgeInsets.only(left: 3, right: 8),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Expanded(
                flex: 5,
                child: Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Texto(
                          titulo: 'Classif',
                          value: '${item['pon_classi']}º',

                          ///${numpar(unitglob.torcodigo, item['pon_ano'])}',
                        ),
                        Texto(
                          titulo: 'Pontos',
                          value: item['pon_pontos'].toString(),
                        ),
                        Texto(
                          titulo: 'Jogos',
                          value: item['pon_jogos'].toString(),
                        ),
                        Texto(
                          titulo: 'Vitórias',
                          value: item['pon_vitori'].toString(),
                        ),
                        Texto(
                          titulo: 'Empates',
                          value: item['pon_empate'].toString(),
                        ),
                      ],
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Texto(
                          titulo: 'Derrotas',
                          value: item['pon_derrot'].toString(),
                        ),
                        Texto(
                          titulo: 'Gols Pró',
                          value: item['pon_golpro'].toString(),
                        ),
                        Texto(
                          titulo: 'Gols Con',
                          value: item['pon_golcon'].toString(),
                        ),
                        Texto(
                          titulo: 'Saldo',
                          value: item['pon_saldo'].toString(),
                        ),
                        Texto(
                          titulo: 'Aproveit',
                          value: item['pon_aprove'].toString(),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        Visibility(
          visible: item['pon_artilh'] != null,
          child: Text(
            "Artilheiro(s): ${item['pon_artilh']}",
            textAlign: TextAlign.center,
            style: const TextStyle(
              fontSize: 16.0,
              //color: Colors.black,
            ),
          ),
        ),
        Visibility(
            visible: item['pon_observ'] != null,
            child: Text(
              "Obs: ${item['pon_observ']}",
              textAlign: TextAlign.center,
              style: const TextStyle(
                fontSize: 16.0,
              ),
            )),
      ],
    );
  }
}

/*Future<String> numpar(String torn, int ano) async {
  //await Future.delayed(Duration(seconds: 5));
  String retorno = '';
  Uri url = Uri.parse('${unitglob.siteurl}23&p=$torn');
  print(url);
  var response = await http.get(url);
  if (response.statusCode == 200) {
    List listaDados = await jsonDecode(response.body);
    for (var i = 0; i < listaDados.length; i++) {
      if (listaDados[i]['pon_ano'] == ano) {
        retorno = await listaDados[i]['numero'].toString();
      }
    }
  }
  print('Retorno: $retorno');
  return await retorno;
}*/

//Montei um widget padrão, para ter um texto em cima do outro
//além da opção de clique
class Texto extends StatelessWidget {
  final String titulo;
  final String value;
  final bool inMarcado;
  const Texto({
    Key? key,
    required this.titulo,
    required this.value,
    this.inMarcado = false,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.all(0),
      decoration: inMarcado
          ? BoxDecoration(
              borderRadius: BorderRadius.circular(5),
              color: Colors.green,
              border: Border.all(),
            )
          : null,
      child: Column(
        children: [
          Text(titulo),
          Text(value,
              style: const TextStyle(
                fontSize: 16.0,
                color: Colors.green,
                fontWeight: FontWeight.bold,
              )),
        ],
      ),
    );
  }
}
