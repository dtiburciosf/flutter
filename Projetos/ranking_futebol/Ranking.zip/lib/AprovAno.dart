import 'package:flutter/material.dart';
import 'package:ranking_futebol/unitglob.dart' as unitglob;
import 'package:ranking_futebol/FramePon.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class AprovAnoPage extends StatefulWidget {
  const AprovAnoPage({super.key});

  @override
  State<AprovAnoPage> createState() => _AprovAnoPageState();
}

class _AprovAnoPageState extends State<AprovAnoPage> {
  String itemInicio = '';
  List<String> listaAnos = [''];
  List listaDados = [];

  bool inLoading = false;

  retornarAnos() async {
    Uri url;
    if (unitglob.opcnum == 30) {
      url = Uri.parse('${unitglob.siteurl}46&p=${unitglob.concodigo}');
    } else {
      url = Uri.parse('${unitglob.siteurl}17&p=${unitglob.torcodigo}');
    }
    inLoading = true;

    var response = await http.get(url);
    if (response.statusCode == 200) {
      List lista = await jsonDecode(response.body);
      if (lista.isNotEmpty) {
        for (var item in lista) {
          listaAnos.add(item['pon_ano'].toString());
          itemInicio = lista[lista.length - 1]['pon_ano'].toString();
        }
      }
    }
    retornarDados(itemInicio);
    setState(() {});
    inLoading = false;
  }

  retornarDados(String ano) async {
    Uri url;

    if (unitglob.opcnum == 30) {
      url = Uri.parse('${unitglob.siteurl}44&p=${ano};${unitglob.concodigo}');
    } else {
      url = Uri.parse('${unitglob.siteurl}47&p=${ano};${unitglob.torcodigo}');
    }
    inLoading = true;
    String vari = '';
    switch (catego) {
      case 'Geral':
        {
          vari = ',M,F,B,';
          break;
        }
      case 'Base':
        {
          vari = ',B,X,Y,';
          break;
        }
      case 'Feminino':
        {
          vari = ',F,X,Y,';
          break;
        }
      default:
        {
          vari = ',M,X,Y,';
        }
    }

    String clubes = ',';
    int i = 0;
    var response = await http.get(url);
    if (response.statusCode == 200) {
      List lista = await jsonDecode(response.body);
      if (lista.isNotEmpty) {
        for (var item in lista) {
          clubes = '${clubes},${lista[i]['clu_ordem'].toString()}';
          i++;
        }
      }
      String urll = '${unitglob.siteurl}45&p=${ano};${clubes},;${vari}&o=4';
      url = Uri.parse(
          '${unitglob.siteurl}45&p=${ano};${clubes};${vari}&o=${unitglob.opcordem}');

      inLoading = true;

      response = await http.get(url);
      if (response.statusCode == 200) {
        listaDados = await jsonDecode(response.body);
      }
      setState(() {});
      inLoading = false;
    }
  }

  @override
  void initState() {
    super.initState();
    unitglob.opcordem = '4';
    retornarAnos();
  }

  String catego = "Masculino";
  var categorias = ['Geral', 'Base', 'Feminino', 'Masculino'];

  @override
  Widget build(BuildContext context) {
    return inLoading == false
        ? Scaffold(
            appBar: AppBar(title: Text(unitglob.tordescri)),
            body: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.only(left: 30, right: 30),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text(
                        'Ano',
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 20,
                        ),
                      ),
                      DropdownButton<String>(
                        value: itemInicio,
                        icon: const Icon(Icons.arrow_drop_down),
                        elevation: 16,
                        style: const TextStyle(
                          color: Colors.deepPurple,
                          fontWeight: FontWeight.bold,
                          fontSize: 20,
                        ),
                        underline: Container(
                          height: 2,
                          color: Colors.deepPurpleAccent,
                        ),
                        onChanged: (String? value) {
                          setState(() {
                            itemInicio = value!;
                            retornarDados(itemInicio);
                          });
                        },
                        items: listaAnos
                            .map<DropdownMenuItem<String>>((String item) {
                          return DropdownMenuItem<String>(
                            value: item,
                            child: Text(item),
                          );
                        }).toList(),
                      ),
                      DropdownButton<String>(
                        value: catego,
                        icon: const Icon(Icons.arrow_drop_down),
                        elevation: 16,
                        style: const TextStyle(
                          color: Colors.deepPurple,
                          fontWeight: FontWeight.bold,
                          fontSize: 20,
                        ),
                        underline: Container(
                          height: 2,
                          color: Colors.deepPurpleAccent,
                        ),
                        onChanged: (String? value) {
                          setState(() {
                            catego = value!;
                            retornarDados(itemInicio);
                          });
                        },
                        items: categorias
                            .map<DropdownMenuItem<String>>((String item) {
                          return DropdownMenuItem<String>(
                            value: item,
                            child: Text(item),
                          );
                        }).toList(),
                      ),
                    ],
                  ),
                ),

                Expanded(
                  child: ListView.builder(
                    itemCount: listaDados.isEmpty ? 0 : listaDados.length,
                    itemBuilder: (BuildContext context, int index) {
                      return PontosFrame(
                        item: listaDados[index],
                        funcao: (String texto) => clicou(texto),
                      );
                    },
                  ),
                ),
                //),
              ],
            ),
          )
        : Scaffold(
            body: Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: const [
                  CircularProgressIndicator(),
                  SizedBox(height: 15),
                  Text('Baixando dados...')
                ],
              ),
            ),
          );
  }

  clicou(String opcao) {
    if ((unitglob.opcnum < 7) ||
        (unitglob.opcnum == 31) ||
        (unitglob.opcnum == 32)) {
      switch (opcao) {
        case 'Pontos':
          {
            unitglob.opcordem = '0';
            unitglob.opcdesc = 'Pontuação';
            break;
          }
        case 'Gols':
          {
            unitglob.opcordem = '1';
            unitglob.opcdesc = 'Melhor Ataque';
            break;
          }
        case 'Saldo':
          {
            unitglob.opcordem = '2';
            unitglob.opcdesc = 'Saldo de Gols';
            break;
          }
        case 'Vitórias':
          {
            unitglob.opcordem = '3';
            unitglob.opcdesc = 'Mais Vitórias';
            break;
          }
        case 'Jogos':
          {
            unitglob.opcordem = '5';
            unitglob.opcdesc = 'Mais Jogos';
            break;
          }
        case 'Aprov':
          {
            unitglob.opcordem = '4';
            unitglob.opcdesc = 'Aproveitamento';
            break;
          }
      }
      setState(() {});
      retornarDados(itemInicio);
    }
  }
}
