import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:http/http.dart' as http;
import 'package:ranking_futebol/unitglob.dart' as unitglob;
import 'package:ranking_futebol/Campanhas.dart';
import 'dart:convert';
//import 'package:url_launcher/url_launcher.dart';

class ClubeCidPage extends StatefulWidget {
  const ClubeCidPage({super.key});

  @override
  State<ClubeCidPage> createState() => _ClubeCidPageState();
}

class _ClubeCidPageState extends State<ClubeCidPage> {
  List listaDados = [];
  bool inLoading = false;

  retornarDados() async {
    var url = Uri.parse(
        '${unitglob.siteurl}26&p=${unitglob.sigla};${unitglob.cidade}');
    inLoading = true;

    var response = await http.get(url);
    if (response.statusCode == 200) {
      listaDados = await jsonDecode(response.body);
    }
    setState(() {});
    inLoading = false;
  }

  @override
  void initState() {
    super.initState();
    retornarDados();
  }

  @override
  Widget build(BuildContext context) {
    return inLoading == false
        ? Scaffold(
            appBar: AppBar(
              title: Text(unitglob.condescri),
            ),
            body: ListView.builder(
              itemCount: listaDados.isEmpty ? 0 : listaDados.length,
              itemBuilder: (BuildContext context, int index) {
                var item = listaDados[index];
                return ListTile(
                  onTap: () {
                    unitglob.cluordem = item['clu_ordem'];
                    unitglob.clubenome = item['clu_nome'];
                    unitglob.fundacao = item['clu_fund'].toString();
                    unitglob.estadio = item['clu_estadi'].toString();

                    Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (_) => const CampanhasPage()));
                  },
                  title: Text(
                    item['clu_nome'],
                    textAlign: TextAlign.center,
                    style: GoogleFonts.fenix(
                      textStyle: const TextStyle(
                        color: Colors.black,
                        letterSpacing: .5,
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                  leading: Visibility(
                    visible: unitglob.mostrafig,
                    child: Expanded(
                      flex: 1,
                      child: Center(
                          child: Image.network(
                        '${'${unitglob.fotos}cl${item['clu_ordem']}'}.jpg',
                        //'${'${unitglob.fotos}cl${unitglob.cluordem}'}.jpg',
                        width: 40,
                        height: 40,
                      )
                          /*CircleAvatar(
                          backgroundImage: NetworkImage(
                              '${'${unitglob.fotos}cl${item['clu_ordem']}'}.jpg'),
                        ),*/
                          ),
                    ),
                  ),
                );
              },
            ),
          )
        : Scaffold(
            body: Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: const [
                  CircularProgressIndicator(),
                  SizedBox(height: 15),
                  Text('Baixando dados...')
                ],
              ),
            ),
          );
  }
}
