// ignore_for_file: use_build_context_synchronously
import 'package:flutter/material.dart';
import 'package:ranking_futebol/pontuacao.dart';
import 'package:ranking_futebol/Ranking.dart';
import 'package:ranking_futebol/Estados.dart';
import 'package:ranking_futebol/Gols.dart';
import 'package:ranking_futebol/unitglob.dart' as unitglob;
import 'package:http/http.dart' as http;
import 'package:ranking_futebol/AprovAno.dart';
import 'dart:convert';

class OpcaoPage extends StatefulWidget {
  const OpcaoPage({super.key});

  @override
  State<OpcaoPage> createState() => _OpcaoPageState();
}

class _OpcaoPageState extends State<OpcaoPage> {
  //@override

  String itemInicio = '';
  String itemFinal = '';
  bool inLoading = false;
  List<String> listaDados = [];

  List<bool> mostra = [
    true,
    true,
    true,
    true,
    true,
    true,
    true,
    true,
    true,
    true,
    true,
    true,
    true,
    true,
    true,
    true,
    true,
    true,
    true,
    true
  ];

  var opcoes = [
    'Pontos, Vitórias, Gols...',
    'Aproveitamento no Ano',
    'Comparação entre Clubes',
    '50 Melhores Campanhas',
    'Por Estado/País',
    'Total por Estado/País',
    'Títulos por Estado/País',
    'Clubes por Estado/País',
    'Ranking 1º ao 10º',
    'Campeões',
    'Maiores Campeões',
    'Mais Participações',
    'Invictos',
    'Rebaixados',
    'Mais Rebaixados',
    'Promovidos',
    'Mais Promovidos',
    'Artilheiros',
    'Maiores Artilheiros',
    'Gols por Ano'
  ];

  void pesq() async {
    List resulta = [];
    var url = Uri.parse('${unitglob.siteurl}35&p=${unitglob.torcodigo};R');
    var response = await http.get(url);
    if (response.statusCode == 200) {
      resulta = await jsonDecode(response.body);
      int numero = resulta[0]['num'];
      if (numero < 1) {
        mostra[13] = false;
        mostra[14] = false;
      }
    }

    url = Uri.parse('${unitglob.siteurl}35&p=${unitglob.torcodigo};P');
    response = await http.get(url);
    if (response.statusCode == 200) {
      resulta = await jsonDecode(response.body);
      int numero = resulta[0]['num'];
      if (numero < 1) {
        mostra[15] = false;
        mostra[16] = false;
      }
    }
    url = Uri.parse('${unitglob.siteurl}18&p=${unitglob.torcodigo}');
    response = await http.get(url);
    if (response.statusCode == 200) {
      resulta = await jsonDecode(response.body);
      int numero = resulta.length;
      if (numero < 2) {
        mostra[4] = false;
        mostra[5] = false;
        mostra[6] = false;
        mostra[7] = false;
      }
    }

    int i = opcoes.length - 1;
    while (i >= 0) {
      //for (var i = opcoes.length; i == 0; i--) {
      if (!mostra[i]) {
        opcoes.removeAt(i);
      }
      i--;
    }

    setState(() {});
    inLoading = false;
  }

  retornarDados() async {
    pesq();
    var url = Uri.parse('${unitglob.siteurl}17&p=${unitglob.torcodigo}');
    inLoading = true;

    var response = await http.get(url);
    unitglob.anomin = '0';
    unitglob.anomax = '';
    unitglob.numano = 0;
    if (response.statusCode == 200) {
      List lista = await jsonDecode(response.body);
      if (lista.isNotEmpty) {
        for (var item in lista) {
          listaDados.add(item['pon_ano'].toString());
          unitglob.anomax = item['pon_ano'].toString();
          if (int.parse(unitglob.anomin) == 0) {
            unitglob.anomin = item['pon_ano'].toString();
          }
          unitglob.numano = unitglob.numano + 1;
          unitglob.anot.add(int.parse(unitglob.anomax));
        }
        itemInicio = lista[0]['pon_ano'].toString();
        itemFinal = lista[lista.length - 1]['pon_ano'].toString();
      }
    }

    setState(() {});
    inLoading = false;
  }

  @override
  void initState() {
    super.initState();
    retornarDados();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(unitglob.tordescri)),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.only(left: 30, right: 30),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text(
                  'Período de',
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 20,
                  ),
                ),
                DropdownButton<String>(
                  value: itemInicio,
                  icon: const Icon(Icons.arrow_drop_down),
                  elevation: 2,
                  style: const TextStyle(
                    color: Colors.deepPurple,
                    fontWeight: FontWeight.bold,
                    fontSize: 20,
                  ),
                  underline: Container(
                    height: 2,
                    color: Colors.deepPurpleAccent,
                  ),
                  onChanged: (String? value) {
                    setState(() {
                      itemInicio = value!;
                    });
                  },
                  items:
                      listaDados.map<DropdownMenuItem<String>>((String item) {
                    return DropdownMenuItem<String>(
                      value: item,
                      child: Text(item),
                    );
                  }).toList(),
                ),
                const Text(
                  ' - ',
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 20,
                  ),
                ),
                DropdownButton<String>(
                  value: itemFinal,
                  icon: const Icon(Icons.arrow_drop_down),
                  elevation: 2,
                  style: const TextStyle(
                    color: Colors.deepPurple,
                    fontWeight: FontWeight.bold,
                    fontSize: 20,
                  ),
                  underline: Container(
                    height: 2,
                    color: Colors.deepPurpleAccent,
                  ),
                  onChanged: (String? value) {
                    setState(() {
                      itemFinal = value!;
                    });
                  },
                  items:
                      listaDados.map<DropdownMenuItem<String>>((String item) {
                    return DropdownMenuItem<String>(
                      value: item,
                      child: Text(item),
                    );
                  }).toList(),
                ),
              ],
            ),
          ),
          Expanded(
              child: GridView.count(
            crossAxisCount: 2,
            childAspectRatio: 2,
            controller: ScrollController(keepScrollOffset: false),
            shrinkWrap: true,
            scrollDirection: Axis.vertical,
            children: opcoes.map((String value) {
              return InkWell(
                onTap: () async {
                  await showOpcao(value);
                },
                child: Container(
                  height: 150.0,
                  margin: const EdgeInsets.all(5.0),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(5),
                    color: Colors.green.shade100,
                  ),
                  child: Center(
                    child: Text(
                      value,
                      textAlign: TextAlign.center,
                      style: const TextStyle(
                        fontSize: 20.0,
                        color: Colors.black,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ),
              );
            }).toList(),
          ))
        ],
      ),
    );
  }

  showOpcao(String value) async {
    unitglob.ano1 = itemInicio;
    unitglob.ano2 = itemFinal;
    switch (value) {
      case 'Pontos, Vitórias, Gols...':
        {
          unitglob.visivel = false;
          unitglob.opcnum = 1;
          unitglob.opcdesc = 'Pontuação';
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => const PontuacaoPage(),
            ),
          );
          break;
        }

      case 'Aproveitamento no Ano':
        {
          unitglob.visivel = false;
          unitglob.opcnum = 31;
          unitglob.opcdesc = value;
          Navigator.push(
              context, MaterialPageRoute(builder: (_) => const AprovAnoPage()));
          break;
        }

      case '50 Melhores Campanhas':
        {
          unitglob.visivel = false;
          unitglob.opcnum = 21;
          unitglob.opcdesc = value;
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => const PontuacaoPage(),
            ),
          );
          break;
        }

      case 'Por Estado/País':
        {
          //unitglob.visivel = false;
          unitglob.opcnum = 19;
          unitglob.opcdesc = value;
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => const EstadosPage(),
            ),
          );
          break;
        }

      case 'Total por Estado/País':
        {
          //unitglob.visivel = false;
          unitglob.opcnum = 7;
          unitglob.opcdesc = value;
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => const PontuacaoPage(),
            ),
          );
          break;
        }

      case 'Títulos por Estado/País':
        {
          //unitglob.visivel = false;
          unitglob.opcnum = 11;
          unitglob.opcdesc = value;
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => const RankingPage(),
            ),
          );
          break;
        }

      case 'Clubes por Estado/País':
        {
          //unitglob.visivel = false;
          unitglob.opcnum = 22;
          unitglob.opcdesc = value;
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => const RankingPage(),
            ),
          );
          break;
        }

      case 'Ranking 1º ao 10º':
        {
          //unitglob.visivel = false;
          unitglob.opcnum = 8;
          unitglob.opcdesc = value;
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => const RankingPage(),
            ),
          );
          break;
        }

      case 'Campeões':
        {
          //unitglob.visivel = false;
          unitglob.opcnum = 9;
          unitglob.opcdesc = value;
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => const PontuacaoPage(),
            ),
          );
          break;
        }

      case 'Maiores Campeões':
        {
          //unitglob.visivel = false;
          unitglob.opcnum = 10;
          unitglob.opcdesc = value;
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => const RankingPage(),
            ),
          );
          break;
        }

      case 'Mais Participações':
        {
          //unitglob.visivel = false;
          unitglob.opcnum = 12;
          unitglob.opcdesc = value;
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => const RankingPage(),
            ),
          );
          break;
        }

      case 'Invictos':
        {
          //unitglob.visivel = false;
          unitglob.opcnum = 13;
          unitglob.opcdesc = value;
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => const RankingPage(),
            ),
          );
          break;
        }

      case 'Rebaixados':
        {
          //unitglob.visivel = false;
          unitglob.opcnum = 23;
          unitglob.opcdesc = value;
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => const PontuacaoPage(),
            ),
          );
          break;
        }

      case 'Mais Rebaixados':
        {
          //unitglob.visivel = false;
          unitglob.opcnum = 25;
          unitglob.opcdesc = value;
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => const RankingPage(),
            ),
          );
          break;
        }

      case 'Promovidos':
        {
          //unitglob.visivel = false;
          unitglob.opcnum = 24;
          unitglob.opcdesc = value;
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => const PontuacaoPage(),
            ),
          );
          break;
        }

      case 'Mais Promovidos':
        {
          //unitglob.visivel = false;
          unitglob.opcnum = 26;
          unitglob.opcdesc = value;
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => const RankingPage(),
            ),
          );
          break;
        }

      case 'Artilheiros':
        {
          //unitglob.visivel = false;
          unitglob.opcnum = 14;
          unitglob.opcdesc = value;
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => const RankingPage(),
            ),
          );
          break;
        }

      case 'Maiores Artilheiros':
        {
          //unitglob.visivel = false;
          unitglob.opcnum = 15;
          unitglob.opcdesc = value;
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => const RankingPage(),
            ),
          );
          break;
        }

      case 'Gols por Ano':
        {
          //unitglob.visivel = false;
          unitglob.opcnum = 16;
          unitglob.opcdesc = value;
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => const GolsPage(),
            ),
          );
          break;
        }

      default:
    }
  }
}
