import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:http/http.dart' as http;
import 'package:ranking_futebol/unitglob.dart' as unitglob;
import 'package:ranking_futebol/Cidades.dart';
import 'package:ranking_futebol/pontuacao.dart';
import 'dart:convert';
//import 'package:url_launcher/url_launcher.dart';

class EstadosPage extends StatefulWidget {
  const EstadosPage({super.key});

  @override
  State<EstadosPage> createState() => _EstadosPageState();
}

class _EstadosPageState extends State<EstadosPage> {
  List listaDados = [];
  bool inLoading = false;

  retornarDados() async {
    Uri url;
    if (unitglob.opcnum != 19) {
      url = Uri.parse('${unitglob.siteurl}33&p=${unitglob.concodigo}');
    } else {
      url = Uri.parse(
          '${unitglob.siteurl}30&p=${unitglob.torcodigo};${unitglob.ano1};${unitglob.ano2}');
    }
    inLoading = true;

    var response = await http.get(url);
    if (response.statusCode == 200) {
      listaDados = await jsonDecode(response.body);
    }
    setState(() {});
    inLoading = false;
  }

  @override
  void initState() {
    super.initState();
    retornarDados();
  }

  @override
  Widget build(BuildContext context) {
    return inLoading == false
        ? Scaffold(
            appBar: AppBar(
              title: Text(unitglob.opcdesc),
            ),
            body: ListView.builder(
              itemCount: listaDados.isEmpty ? 0 : listaDados.length,
              itemBuilder: (BuildContext context, int index) {
                var item = listaDados[index];
                return ListTile(
                    onTap: () {
                      unitglob.estado = item['est_estado'];
                      unitglob.sigla = item['clu_estado'];

                      unitglob.opcnum != 19
                          ? Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (_) => const CidadesPage()))
                          : Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (_) => const PontuacaoPage()));
                    },
                    title: Text(
                      item['est_estado'],
                      textAlign: TextAlign.center,
                      style: GoogleFonts.fenix(
                        textStyle: const TextStyle(
                          color: Colors.black,
                          letterSpacing: .5,
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                    leading: Image.network(
                      '${'${unitglob.fotos}est_' + item['clu_estado']}.jpg',
                      width: 40,
                      height: 40,
                    ));
              },
            ),
          )
        : Scaffold(
            body: Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: const [
                  CircularProgressIndicator(),
                  SizedBox(height: 15),
                  Text('Baixando dados...')
                ],
              ),
            ),
          );
  }
}
