import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:ranking_futebol/unitglob.dart' as unitglob;
import 'package:ranking_futebol/FrameGols.dart';
import 'dart:math';
//import 'package:url_launcher/url_launcher.dart';

class GolsPage extends StatefulWidget {
  const GolsPage({super.key});

  @override
  State<GolsPage> createState() => _GolsPageState();
}

class _GolsPageState extends State<GolsPage> {
  List listaDados = [];
  bool inLoading = false;

  retornarDados() async {
    String siteof = unitglob.siteurl +
        (unitglob.opcnum - 5).toString() +
        '&p=' +
        unitglob.torcodigo;
    print(siteof);
    var url = Uri.parse(siteof);
    inLoading = true;
    int totgol = 0;
    int totjog = 0;
    int numero = 0;

    var response = await http.get(url);
    if (response.statusCode == 200) {
      listaDados = await jsonDecode(response.body);
      if (listaDados.isNotEmpty) {
        for (var item in listaDados) {
          totgol =
              totgol + int.parse(listaDados[numero]['pon_golpro'].toString());
          totjog =
              totjog + int.parse(listaDados[numero]['pon_jogos'].toString());
          numero = numero + 1;
        }
        listaDados.add(
          {
            "pon_ano": 9999,
            "pon_golpro": totgol,
            "pon_jogos": totjog,
            "pon_media": (totgol / totjog).toStringAsFixed(3),
          },
        );
      }
    }
    setState(() {});
    inLoading = false;
  }

  @override
  void initState() {
    super.initState();
    retornarDados();
  }

  @override
  Widget build(BuildContext context) {
    return inLoading == false
        ? Scaffold(
            appBar: AppBar(
              title: Text(unitglob.tordescri),
            ),
            body: Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Text(
                      unitglob.opcdesc,
                      textAlign: TextAlign.center,
                      style: const TextStyle(
                        fontSize: 20.0,
                        color: Colors.black,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
                Expanded(
                  child: ListView.builder(
                    itemCount: listaDados.isEmpty ? 0 : listaDados.length,
                    itemBuilder: (BuildContext context, int index) {
                      var item = listaDados[index];
                      return GolsFrame(
                        item: item,
                        funcao: (String texto) => clicou(texto),
                        index: index + 1,
                      );
                    },
                  ),
                ),
                const Text(
                  'Clique em Ano, Gols ou Média pra mudar a ordem',
                  textAlign: TextAlign.right,
                  style: TextStyle(
                    fontSize: 12.0,
                    color: Colors.redAccent,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
          )
        : Scaffold(
            body: Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: const [
                  CircularProgressIndicator(),
                  SizedBox(height: 15),
                  Text('Baixando dados...')
                ],
              ),
            ),
          );
  }

  clicou(String opcao) {
    switch (opcao) {
      case 'Ano':
        {
          unitglob.opcnum = 16;
          unitglob.opcdesc = 'Gols por Ano';
          break;
        }

      case 'Gols':
        {
          unitglob.opcnum = 17;
          unitglob.opcdesc = 'Mais Gols por Ano';
          break;
        }

      case 'Média':
        {
          unitglob.opcnum = 18;
          unitglob.opcdesc = 'Média de Gols por Ano';
          break;
        }
    }
    setState(() {});
    retornarDados();
  }
}
