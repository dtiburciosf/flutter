import 'package:flutter/material.dart';

class GolsFrame extends StatelessWidget {
  final Map item;
  final Function(String texto) funcao;
  final int? index;
  const GolsFrame({
    Key? key,
    required this.item,
    required this.funcao,
    this.index,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        /*Text(
          item['pon_ano'].toString(),
          textAlign: TextAlign.center,
          style: const TextStyle(
              fontSize: 20.0,
              decoration: TextDecoration.underline,
              fontWeight: FontWeight.bold),
        ),*/
        Container(
          color: Colors.white,
          padding: const EdgeInsets.all(0),
          margin: const EdgeInsets.fromLTRB(25, 5, 25, 5),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Expanded(
                flex: 5,
                child: Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Texto(
                          titulo: 'Ano',
                          value: item['pon_ano'].toString(),
                          funcao: () => funcao('Ano'),
                        ),
                        Texto(
                          titulo: 'Gols',
                          value: item['pon_golpro'].toString(),
                          funcao: () => funcao('Gols'),
                        ),
                        Texto(
                          titulo: 'Jogos',
                          value: item['pon_jogos'].toString(),
                          funcao: () => funcao('Jogos'),
                        ),
                        Texto(
                          titulo: 'Média',
                          value: item['pon_media'].toString(), //'fazer conta',
                          funcao: () => funcao('Média'),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

//Montei um widget padrão, para ter um texto em cima do outro
//além da opção de clique
class Texto extends StatelessWidget {
  final String titulo;
  final String value;
  final Function()? funcao;
  final bool inMarcado;
  const Texto({
    Key? key,
    required this.titulo,
    required this.value,
    this.funcao,
    this.inMarcado = false,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.all(0),
      //color: Color(0xFF009688),
      decoration: inMarcado
          ? BoxDecoration(
              borderRadius: BorderRadius.circular(5),
              color: Colors.black,
              border: Border.all(),
            )
          : null,
      child: InkWell(
        onTap: funcao ?? funcao,
        child: Column(
          children: [
            Text(titulo,
                style: const TextStyle(
                  fontSize: 16.0,
                  color: Color(0xFF647483),
                  fontWeight: FontWeight.bold,
                  //backgroundColor: Color(0xFFE0E0E0),
                )),
            Text(value,
                style: const TextStyle(
                  fontSize: 16.0,
                  color: Color(0xFF009688),
                  fontWeight: FontWeight.bold,
                  //color: Color(0xFFE0E0E0),
                )),
          ],
        ),
      ),
    );
  }
}
