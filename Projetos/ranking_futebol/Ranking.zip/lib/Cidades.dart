import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:http/http.dart' as http;
import 'package:ranking_futebol/unitglob.dart' as unitglob;
import 'package:ranking_futebol/ClubeCid.dart';
import 'dart:convert';
//import 'package:url_launcher/url_launcher.dart';

class CidadesPage extends StatefulWidget {
  const CidadesPage({super.key});

  @override
  State<CidadesPage> createState() => _CidadesPageState();
}

class _CidadesPageState extends State<CidadesPage> {
  List listaDados = [];
  bool inLoading = false;

  retornarDados() async {
    var url = Uri.parse('${unitglob.siteurl}25&p=${unitglob.sigla}');
    inLoading = true;

    var response = await http.get(url);
    if (response.statusCode == 200) {
      listaDados = await jsonDecode(response.body);
    }
    setState(() {});
    inLoading = false;
  }

  @override
  void initState() {
    super.initState();
    retornarDados();
  }

  @override
  Widget build(BuildContext context) {
    return inLoading == false
        ? Scaffold(
            appBar: AppBar(
              title: Text('Cidades de ${unitglob.estado}/${unitglob.sigla}'),
            ),
            body: ListView.builder(
              itemCount: listaDados.isEmpty ? 0 : listaDados.length,
              itemBuilder: (BuildContext context, int index) {
                var item = listaDados[index];
                return ListTile(
                  onTap: () {
                    unitglob.cidade = item['clu_cidade'];
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (_) => const ClubeCidPage()));
                  },
                  title: Text(
                    item['clu_cidade'] +
                        ' (' +
                        item['numero'].toString() +
                        ' clube' +
                        (item['numero'] > 1 ? 's' : '') +
                        ')',
                    textAlign: TextAlign.center,
                    style: GoogleFonts.fenix(
                      textStyle: const TextStyle(
                        color: Colors.black,
                        letterSpacing: .5,
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                );
              },
            ),
          )
        : Scaffold(
            body: Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: const [
                  CircularProgressIndicator(),
                  SizedBox(height: 15),
                  Text('Baixando dados...')
                ],
              ),
            ),
          );
  }
}
