import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:ranking_futebol/unitglob.dart' as unitglob;
import 'package:ranking_futebol/FrameRank.dart';
//import 'package:url_launcher/url_launcher.dart';

class RankingPage extends StatefulWidget {
  const RankingPage({super.key});

  @override
  State<RankingPage> createState() => _RankingPageState();
}

class _RankingPageState extends State<RankingPage> {
  List listaDados = [];
  bool inLoading = false;

  retornarDados() async {
    unitglob.numitem = 0;
    String siteof = unitglob.siteurl;
    switch (unitglob.opcnum) {
      case 8:
        siteof =
            '${siteof}3&p=${unitglob.torcodigo};${unitglob.ano1};${unitglob.ano2}';
        break;
      case 10:
        siteof =
            '${siteof}5&p=${unitglob.torcodigo};${unitglob.ano1};${unitglob.ano2}';
        break;
      case 11:
        siteof =
            '${siteof}6&p=${unitglob.torcodigo};${unitglob.ano1};${unitglob.ano2}';
        break;
      case 12:
        siteof =
            '${siteof}7&p=${unitglob.torcodigo};${unitglob.ano1};${unitglob.ano2}';
        break;
      case 13:
        siteof = '${siteof}8&p=${unitglob.torcodigo}';
        break;
      case 14:
        siteof = '${siteof}9&p=${unitglob.torcodigo}';
        break;
      case 22:
        siteof =
            '${siteof}34&p=${unitglob.torcodigo};${unitglob.ano1};${unitglob.ano2}';
        break;
      case 25:
        siteof =
            '${siteof}37&p=${unitglob.torcodigo};${unitglob.ano1};${unitglob.ano2};R';
        break;
      case 26:
        siteof =
            '${siteof}37&p=${unitglob.torcodigo};${unitglob.ano1};${unitglob.ano2};P';
        break;
      default:
        {
          siteof = '${siteof}10&p=${unitglob.torcodigo}';
        }
    }
    unitglob.opcdesc = '${unitglob.opcdesc} ${unitglob.ano1}';
    if (unitglob.ano1 != unitglob.ano2) {
      unitglob.opcdesc = '${unitglob.opcdesc} - ${unitglob.ano2}';
    }
    print(siteof);
    var url = Uri.parse(siteof);
    inLoading = true;

    var response = await http.get(url);
    if (response.statusCode == 200) {
      listaDados = await jsonDecode(response.body);
      try {
        unitglob.prigrupo = listaDados[0]['pon_grupo'];
      } catch (exception) {
        unitglob.prigrupo = '';
      }
    }
    setState(() {});
    inLoading = false;
  }

  @override
  void initState() {
    super.initState();
    unitglob.visivel = ((unitglob.opcnum) == 9 ||
        (unitglob.opcnum) == 23 ||
        (unitglob.opcnum) == 24);
    retornarDados();
  }

  @override
  Widget build(BuildContext context) {
    return inLoading == false
        ? Scaffold(
            appBar: AppBar(
              title: Text(unitglob.opcdesc),
            ),
            body: Column(
              children: [
                Expanded(
                  child: ListView.builder(
                    itemCount: listaDados.isEmpty ? 0 : listaDados.length,
                    itemBuilder: (BuildContext context, int index) {
                      var item = listaDados[index];
                      return RankingFrame(
                        item: item,
                        //funcao: (String texto) => clicou(texto),
                        index: index + 1,
                      );
                    },
                  ),
                ),
              ],
            ),
          )
        : Scaffold(
            body: Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: const [
                  CircularProgressIndicator(),
                  SizedBox(height: 15),
                  Text('Baixando dados...')
                ],
              ),
            ),
          );
  }
}
