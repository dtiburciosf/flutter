import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:ranking_futebol/unitglob.dart' as unitglob;
import 'package:ranking_futebol/FramePon.dart';
//import 'package:url_launcher/url_launcher.dart';

class PontuacaoPage extends StatefulWidget {
  const PontuacaoPage({super.key});

  @override
  State<PontuacaoPage> createState() => _PontuacaoPageState();
}

class _PontuacaoPageState extends State<PontuacaoPage> {
  List listaDados = [];
  bool inLoading = false;
  String anoesq = unitglob.ano1;
  String anodir = unitglob.ano1;

  void aux() {
    for (var i = 1; i <= unitglob.numano; i++) {
      if (int.parse(unitglob.ano1) == unitglob.anot[i]) {
        anoesq = unitglob.anot[i - 1].toString();
        if (i != unitglob.numano) {
          anodir = unitglob.anot[i + 1].toString();
        }
      }
    }
  }

  retornarDados() async {
    unitglob.numitem = 0;
    String siteof = unitglob.siteurl;
    switch (unitglob.opcnum) {
      case 7:
        siteof =
            '${siteof}2&p=${unitglob.torcodigo};${unitglob.ano1};${unitglob.ano2}';
        break;
      case 9:
        siteof =
            '${siteof}22&p=${unitglob.torcodigo};${unitglob.ano1};${unitglob.ano2}';
        break;
      case 19:
        siteof =
            '${siteof}29&p=${unitglob.torcodigo};${unitglob.ano1};${unitglob.ano2};${unitglob.clubenome}';
        break;
      case 21:
        siteof =
            '${siteof}21&p=${unitglob.torcodigo};${unitglob.ano1};${unitglob.ano2}';
        break;
      case 23:
        siteof =
            '${siteof}36&p=${unitglob.torcodigo};${unitglob.ano1};${unitglob.ano2};R';
        break;
      case 24:
        siteof =
            '${siteof}36&p=${unitglob.torcodigo};${unitglob.ano1};${unitglob.ano2};P';
        break;
      default:
        {
          if (unitglob.ano1 == unitglob.ano2) {
            siteof = '${siteof}1';
          } else {
            siteof = '${siteof}0';
          }
          siteof =
              '$siteof&p=${unitglob.torcodigo};${unitglob.ano1};${unitglob.ano2}&o=';

          if (unitglob.ano1 == unitglob.ano2 &&
              (unitglob.opcnum == 1 || unitglob.opcnum == 20)) {
            siteof = '${siteof}6';
          } else {
            switch (unitglob.opcnum) {
              case 1:
                siteof = '${siteof}0';
                break;
              case 20:
                siteof = '${siteof}0';
                break;
              case 2:
                siteof = '${siteof}1';
                break;
              case 3:
                siteof = '${siteof}2';
                break;
              case 4:
                siteof = '${siteof}3';
                break;
              case 6:
                siteof = '${siteof}4';
                break;
              default:
                siteof = '${siteof}5';
            }
          }
        }
    }
    unitglob.opcdesc = '${unitglob.opcdesc} ${unitglob.ano1}';
    if (unitglob.ano1 != unitglob.ano2) {
      unitglob.opcdesc = '${unitglob.opcdesc} - ${unitglob.ano2}';
    }
    aux();
    print(siteof);
    var url = Uri.parse(siteof);
    inLoading = true;

    var response = await http.get(url);
    if (response.statusCode == 200) {
      listaDados = await jsonDecode(response.body);
      unitglob.maximo = listaDados.length;
    }
    setState(() {});
    inLoading = false;
  }

  @override
  void initState() {
    super.initState();
    unitglob.visivel = ((unitglob.opcnum) == 9 ||
        (unitglob.opcnum) == 23 ||
        (unitglob.opcnum) == 24);
    unitglob.antgrupo = '';
    unitglob.privez = true;
    unitglob.numreg = 0;
    retornarDados();
  }

  @override
  Widget build(BuildContext context) {
    return inLoading == false
        ? Scaffold(
            appBar: AppBar(
              title: Text(unitglob.tordescri),
            ),
            body: Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Visibility(
                      visible: (unitglob.opcnum < 7 &&
                          unitglob.ano1 == unitglob.ano2 &&
                          int.parse(unitglob.ano1) >
                              int.parse(unitglob.anomin)),
                      child: Text(
                        anoesq,
                        textAlign: TextAlign.left,
                        //funcao: (String texto) => seleano('E', texto),
                        style: const TextStyle(
                          fontSize: 17.0,
                          color: Colors.black,
                          fontWeight: FontWeight.bold,
                          backgroundColor: Colors.transparent,
                        ),
                      ),
                    ),
                    Text(
                      unitglob.opcdesc,
                      textAlign: TextAlign.center,
                      style: const TextStyle(
                        fontSize: 20.0,
                        color: Colors.black,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    Visibility(
                      visible: (unitglob.opcnum < 7 &&
                          unitglob.ano1 == unitglob.ano2 &&
                          unitglob.ano1 != unitglob.anomax),
                      child: Text(
                        anodir,
                        textAlign: TextAlign.right,
                        //funcao: (String texto) => seleano('D', texto),

                        style: const TextStyle(
                          fontSize: 17.0,
                          color: Colors.black,
                          fontWeight: FontWeight.bold,
                          backgroundColor: Colors.transparent,
                        ),
                      ),
                    ),
                  ],
                ),
                Expanded(
                  child: ListView.builder(
                    itemCount: listaDados.isEmpty ? 0 : listaDados.length,
                    itemBuilder: (BuildContext context, int index) {
                      var item = listaDados[index];
                      return PontosFrame(
                        item: item,
                        funcao: (String texto) => clicou(texto),
                        index: index + 1,
                      );
                    },
                  ),
                ),
                Visibility(
                  visible: unitglob.opcnum < 7,
                  child: const Text(
                    'Clique na informação desejada pra mudar a ordem',
                    textAlign: TextAlign.right,
                    style: TextStyle(
                      fontSize: 12.0,
                      color: Colors.redAccent,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ],
            ),
          )
        : Scaffold(
            body: Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: const [
                  CircularProgressIndicator(),
                  SizedBox(height: 15),
                  Text('Baixando dados...')
                ],
              ),
            ),
          );
  }

  String textoGrupo(List lista, int index) {
    /*if (!lista.containskey('pon_grupo')) {
      return '';
    }
     else {
    print('Index $index');
  }*/

    if (index < 1) {
      return lista[index]['pon_grupo'];
    } else if (lista[index - 1]['pon_grupo'] != lista[index]['pon_grupo']) {
      return lista[index]['pon_grupo'];
    } else {
      return '';
    }
  }

  clicou(String opcao) {
    if (unitglob.opcnum < 7) {
      switch (opcao) {
        case 'Pontos':
          {
            unitglob.opcnum = 1;
            unitglob.opcdesc = 'Pontuação';
            break;
          }
        case 'Gols':
          {
            unitglob.opcnum = 2;
            unitglob.opcdesc = 'Melhor Ataque';
            break;
          }
        case 'Saldo':
          {
            unitglob.opcnum = 3;
            unitglob.opcdesc = 'Saldo de Gols';
            break;
          }
        case 'Vitórias':
          {
            unitglob.opcnum = 4;
            unitglob.opcdesc = 'Mais Vitórias';
            break;
          }
        case 'Jogos':
          {
            unitglob.opcnum = 5;
            unitglob.opcdesc = 'Mais Jogos';
            break;
          }
        case 'Aprov':
          {
            unitglob.opcnum = 6;
            unitglob.opcdesc = 'Aproveitamento';
            break;
          }
      }
      setState(() {});
      retornarDados();
    }
  }

  seleano(String item, ano) {
    unitglob.ano1 = ano;
    unitglob.ano2 = ano;
    if (item == 'E') {
      anodir = ano;
      for (var i = 1; i <= unitglob.numano; i++) {
        if (int.parse(ano) == unitglob.anot[i]) {
          break;
        }
        if (i > 1) {
          anoesq = unitglob.anot[i - 1].toString();
        }
      }
    } else {
      anoesq = ano;
      for (var i = 1; i <= unitglob.numano; i++) {
        if (int.parse(ano) == unitglob.anot[i]) {
          anodir = unitglob.anot[i + 1].toString();
          break;
        }
      }
    }
  }
}
