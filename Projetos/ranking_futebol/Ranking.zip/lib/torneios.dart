import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:http/http.dart' as http;
import 'package:ranking_futebol/anocampe.dart';
import 'package:ranking_futebol/AprovAno.dart';
import 'package:ranking_futebol/Estados.dart';
import 'package:ranking_futebol/opcao.dart';
import 'package:ranking_futebol/unitglob.dart' as unitglob;
import 'dart:convert';
//import 'package:url_launcher/url_launcher.dart';

class TorneioPage extends StatefulWidget {
  const TorneioPage({super.key});

  @override
  State<TorneioPage> createState() => _TorneioPageState();
}

class _TorneioPageState extends State<TorneioPage> {
  List listaDados = [];
  bool inLoading = false;

  retornarDados() async {
    var url = Uri.parse('${unitglob.siteurl}48&p=${unitglob.concodigo};1');
    inLoading = true;

    var response = await http.get(url);
    if (response.statusCode == 200) {
      listaDados = await jsonDecode(response.body);
    }
    setState(() {});
    inLoading = false;
  }

  @override
  void initState() {
    super.initState();
    retornarDados();
  }

  @override
  Widget build(BuildContext context) {
    return inLoading == false
        ? Scaffold(
            appBar: AppBar(
              title: Text(unitglob.condescri),
            ),
            body: ListView.builder(
              itemCount: listaDados.isEmpty ? 0 : listaDados.length,
              itemBuilder: (BuildContext context, int index) {
                var item = listaDados[index];
                return ListTile(
                    onTap: () {
                      unitglob.torcodigo = item['tor_codigo'];
                      unitglob.tordescri = item['tor_descri'];

                      switch (item['tor_descri']) {
                        case 'Aproveitamento no Ano':
                          {
                            unitglob.visivel = false;
                            unitglob.opcnum = 30;
                            unitglob.opcdesc = item['tor_descri'];
                            Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (_) => const AprovAnoPage()));
                            break;
                          }
                        case 'Campeões do Ano':
                          {
                            unitglob.visivel = false;
                            unitglob.opcnum = 32;
                            unitglob.opcdesc = item['tor_descri'];
                            Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (_) => const AnoCampePage()));
                            break;
                          }
                        case 'Clubes por Cidade':
                          {
                            unitglob.visivel = false;
                            unitglob.opcnum = 32;
                            unitglob.opcdesc = item['tor_descri'];
                            Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (_) => const EstadosPage()));
                            break;
                          }
                        case 'Evolução dos Clubes':
                          {
                            break;
                          }
                        case 'Evolução por Torneio':
                          {
                            break;
                          }
                        default:
                          {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (_) => const OpcaoPage(),
                              ),
                            );
                          }
                      }
                    },
                    title: Text(
                      item['tor_descri'],
                      textAlign: TextAlign.center,
                      style: GoogleFonts.fenix(
                        textStyle: const TextStyle(
                          color: Colors.black,
                          letterSpacing: .5,
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                    leading: Image.network(
                      '${'${unitglob.fotos}est_' + item['est_pais']}.jpg',
                      width: 40,
                      height: 40,
                    ));
              },
            ),
          )
        : Scaffold(
            body: Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: const [
                  CircularProgressIndicator(),
                  SizedBox(height: 15),
                  Text('Baixando dados...')
                ],
              ),
            ),
          );
  }
}
