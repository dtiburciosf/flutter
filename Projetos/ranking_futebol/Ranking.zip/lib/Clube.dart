import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:ranking_futebol/unitglob.dart' as unitglob;
import 'package:ranking_futebol/FrameClube.dart';

class ClubePage extends StatefulWidget {
  const ClubePage({super.key});

  @override
  State<ClubePage> createState() => _ClubePageState();
}

class _ClubePageState extends State<ClubePage> {
  List listaDados = [];
  bool inLoading = false;

  retornarDados() async {
    var url = Uri.parse(
        '${unitglob.siteurl}14&p=${unitglob.torcodigo};${unitglob.clubenome};${unitglob.sigla}');
    inLoading = true;

    var response = await http.get(url);
    if (response.statusCode == 200) {
      listaDados = await jsonDecode(response.body);
    }
    setState(() {});
    inLoading = false;
  }

  @override
  void initState() {
    super.initState();
    retornarDados();
  }

  @override
  Widget build(BuildContext context) {
    if (inLoading == false) {
      return Scaffold(
        appBar: AppBar(
          title: Text(unitglob.tordescri),
        ),
        body: Column(children: [
          Column(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Image.network(
                '${'${unitglob.fotos}cl${unitglob.cluordem}'}.jpg',
                width: 40,
                height: 40,
              )
            ],
          ),
          Column(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Text(
                  unitglob.clubenome,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    fontSize: 20.0,
                    color: Colors.black,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                Visibility(
                  visible: unitglob.fundacao != null,
                  child: Text(
                    'Fundação: ${unitglob.fundacao}',
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                      fontSize: 15.0,
                      color: Colors.black,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                Visibility(
                  visible: unitglob.estadio != null,
                  child: Text(
                    'Estádio: ${unitglob.estadio}',
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                      fontSize: 15.0,
                      color: Colors.black,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                )
              ]),
          Expanded(
            child: ListView.builder(
              itemCount: listaDados.isEmpty ? 0 : listaDados.length,
              itemBuilder: (BuildContext context, int index) {
                var item = listaDados[index];
                return ClubeFrame(
                  item: item,
                  index: index + 1,
                );
              },
            ),
          ),
        ]),
      );
    } else {
      return Scaffold(
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: const [
              CircularProgressIndicator(),
              SizedBox(height: 15),
              Text('Baixando dados...')
            ],
          ),
        ),
      );
    }
  }
}
