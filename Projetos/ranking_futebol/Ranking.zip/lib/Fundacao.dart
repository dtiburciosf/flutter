import 'package:flutter/material.dart';
import 'package:ranking_futebol/unitglob.dart' as unitglob;
import 'package:ranking_futebol/FrameRank.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class FundacaoPage extends StatefulWidget {
  const FundacaoPage({super.key});

  @override
  State<FundacaoPage> createState() => _FundacaoPageState();
}

class _FundacaoPageState extends State<FundacaoPage> {
  List<String> listaDias = [
    '01',
    '02',
    '03',
    '04',
    '05',
    '06',
    '07',
    '08',
    '09',
    '10',
    '11',
    '12',
    '13',
    '14',
    '15',
    '16',
    '17',
    '18',
    '19',
    '20',
    '21',
    '22',
    '23',
    '24',
    '25',
    '26',
    '27',
    '28',
    '29',
    '30',
    '31'
  ];
  List listaDados = [];
  bool inLoading = false;
  List<String> meses = [
    'Janeiro',
    'Fevereiro',
    'Março',
    'Abril',
    'Maio',
    'Junho',
    'Julho',
    'Agosto',
    'Setembro',
    'Outubro',
    'Novembro',
    'Dezembro'
  ];

  bool privez = true;
  String diaatu = DateTime.now().day.toString().padLeft(2, '0');
  int mes = DateTime.now().month - 1;
  String mesatu = '';
  inicio() {
    String mm = meses[mes];
    return mm;
  }

  retornarDados(String dia, String mes) async {
    if (privez) {
      mesatu = inicio();
      privez = false;
    }
    int i = 0;
    for (i = 0; i < meses.length; i++) {
      if (mesatu == meses[i]) {
        break;
      }
    }
    Uri url = Uri.parse('${unitglob.siteurl}43&p=$dia;${i + 1}');
    print(url);
    inLoading = true;

    var response = await http.get(url);
    if (response.statusCode == 200) {
      listaDados = await jsonDecode(response.body);

      setState(() {});
      inLoading = false;
    }
  }

  @override
  void initState() {
    super.initState();
    retornarDados(diaatu, mesatu);
  }

  @override
  Widget build(BuildContext context) {
    return inLoading == false
        ? Scaffold(
            appBar: AppBar(title: Text(unitglob.tordescri)),
            body: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.only(left: 30, right: 30),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text(
                        'Dia',
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 20,
                        ),
                      ),
                      DropdownButton<String>(
                        value: diaatu,
                        icon: const Icon(Icons.arrow_drop_down),
                        elevation: 16,
                        style: const TextStyle(
                          color: Colors.deepPurple,
                          fontWeight: FontWeight.bold,
                          fontSize: 20,
                        ),
                        underline: Container(
                          height: 2,
                          color: Colors.deepPurpleAccent,
                        ),
                        onChanged: (String? value) {
                          setState(() {
                            diaatu = value!;
                            retornarDados(diaatu, mesatu);
                          });
                        },
                        items: listaDias
                            .map<DropdownMenuItem<String>>((String item) {
                          return DropdownMenuItem<String>(
                            value: item,
                            child: Text(item),
                          );
                        }).toList(),
                      ),
                      const Text(
                        'Mês',
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 20,
                        ),
                      ),
                      DropdownButton<String>(
                        value: mesatu,
                        icon: const Icon(Icons.arrow_drop_down),
                        elevation: 16,
                        style: const TextStyle(
                          color: Colors.deepPurple,
                          fontWeight: FontWeight.bold,
                          fontSize: 20,
                        ),
                        underline: Container(
                          height: 2,
                          color: Colors.deepPurpleAccent,
                        ),
                        onChanged: (String? value) {
                          setState(() {
                            mesatu = value!;
                            retornarDados(diaatu, mesatu);
                          });
                        },
                        items:
                            meses.map<DropdownMenuItem<String>>((String item) {
                          return DropdownMenuItem<String>(
                            value: item,
                            child: Text(item),
                          );
                        }).toList(),
                      ),
                    ],
                  ),
                ),

                Expanded(
                  child: ListView.builder(
                    itemCount: listaDados.isEmpty ? 0 : listaDados.length,
                    itemBuilder: (BuildContext context, int index) {
                      return RankingFrame(
                        item: listaDados[index],
                      );
                    },
                  ),
                ),
                //),
              ],
            ),
          )
        : Scaffold(
            body: Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: const [
                  CircularProgressIndicator(),
                  SizedBox(height: 15),
                  Text('Baixando dados...')
                ],
              ),
            ),
          );
  }
}
