import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'dart:io' show Platform;
import 'package:ranking_futebol/torneios.dart';
import 'package:ranking_futebol/Fundacao.dart';
import 'package:ranking_futebol/unitglob.dart' as unitglob;
import 'package:url_launcher/url_launcher.dart';
//import 'package:google_mobile_ads/google_mobile_ads.dart';

class PrincipalPage extends StatefulWidget {
  const PrincipalPage({super.key});

  @override
  State<PrincipalPage> createState() => _PrincipalPageState();
}

class _PrincipalPageState extends State<PrincipalPage> {
  //@override
  List listaDados = [];
  bool inLoading = false;
  retornarDados() async {
    inLoading = true;
    Uri url;
    if (Platform.isIOS) {
      url = Uri.parse('${unitglob.siteurl}41');
      var response = await http.get(url);
      if (response.statusCode == 200) {
        listaDados = await jsonDecode(response.body);
        String mostra = listaDados[0]['ESC_MOSTRA'];
        switch (mostra) {
          case 'S':
            {
              unitglob.mostrafig == true;
              break;
            }
          default:
            unitglob.mostrafig == false;
        }
      }
    }

    url = Uri.parse('${unitglob.siteurl}20&p=3');

    var response = await http.get(url);
    if (response.statusCode == 200) {
      listaDados = await jsonDecode(response.body);
      listaDados.add(
        {
          "con_descri": "Fundação dos Clubes e Países",
          "con_espano": "Fundación de Clubes y Países",
          "con_franca": "Fondation des Clubs et des Pays",
          "con_alemao": "Gründung von Clubs und Ländern'",
          "con_englis": "Foundation of Clubs and Countries",
          "con_codigo": "continente",
        },
      );
    }
    setState(() {});
    inLoading = false;
  }

  Future<void> _launchUrl() async {
    Uri? url;
    if (Platform.isAndroid) {
      url = Uri.parse(
          'https://play.google.com/store/apps/details?id=br.danieltiburciosf.rankingfutebol');
    } else if (Platform.isIOS) {
      url = Uri.parse(
          'https://apps.apple.com/us/app/ranking-do-futebol/id1468108067');
    }
    if (!await launchUrl(url!)) {
      throw 'Could not launch $url';
    }
  }

  @override
  void initState() {
    super.initState();
//    myBanner.load();
    retornarDados();
  }

  @override
  Widget build(BuildContext context) {
    return inLoading == false
        ? Scaffold(
            appBar: AppBar(
              title: const Text('Ranking do Futebol'),
              actions: [
                TextButton(
                  onPressed: () {
                    _launchUrl();
                  },
                  child: const Text(
                    'Avaliar',
                    style: TextStyle(
                      color: Colors.white,
                    ),
                  ),
                ),
              ],

              //widget.titulo),
            ),
            body: ListView.builder(
              itemCount: listaDados.isEmpty ? 0 : listaDados.length,
              itemBuilder: (BuildContext context, int index) {
                var item = listaDados[index];
                return ListTile(
                  onTap: () {
                    unitglob.concodigo = item['con_codigo'];
                    unitglob.condescri = item['con_descri'];
                    if (item['con_descri'] == 'Fundação dos Clubes e Países') {
                      unitglob.opcnum = 32;
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => const FundacaoPage(),
                        ),
                      );
                    } else {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (_) => const TorneioPage()));
                    }
                  },
                  title: Text(
                    item['con_descri'],
                    textAlign: TextAlign.center,
                    style: GoogleFonts.fenix(
                      textStyle: const TextStyle(
                        color: Colors.black,
                        letterSpacing: .5,
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                );
              },
            ),
          )
        : Scaffold(
            body: Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: const [
                  CircularProgressIndicator(),
                  SizedBox(height: 15),
                  Text('Baixando dados...')
                ],
              ),
            ),
          );
  }
}

/*final BannerAd myBanner = BannerAd(
  adUnitId: admobid, // 'ca-app-pub-7390880956140424/7744419038',
  size: AdSize.banner,
  request: AdRequest(),
  listener: BannerAdListener(),


final BannerAdListener listener = BannerAdListener(
  // Called when an ad is successfully received.
  onAdLoaded: (Ad ad) => AlertDialog('Ad loaded.'),
  // Called when an ad request failed.
  onAdFailedToLoad: (Ad ad, LoadAdError error) {
    // Dispose the ad here to free resources.
    ad.dispose();
    AlertDialog('Ad failed to load: $error');
  },
  // Called when an ad opens an overlay that covers the screen.
  onAdOpened: (Ad ad) => AlertDialog('Ad opened.'),
  // Called when an ad removes an overlay that covers the screen.
  onAdClosed: (Ad ad) => AlertDialog('Ad closed.'),
  // Called when an impression occurs on the ad.
  onAdImpression: (Ad ad) => AlertDialog('Ad impression.'),
);*/

/* opc_num

1 = Pontos
2 = Ataque
3 = Saldo de Gols
4 = Vitórias
5 = Jogos
6 = Aproveitamento
7 = Total Estado/País
8 = Ranking 1º ao 10º
9 = Campeões (PASSOU PARA 22)
10 = Maiores Campeões
11 = Títulos por Estado/País
12 = Mais Participações
13 = Invictos
14 = Artilheiros
15 = Maiores Artilheiros
16 = Gols por Ano
17 = Mais Gols por Ano
18 = Média de Gols
19 = Por Estado/País
20 - Comparação Entre Clubes
21 = 50 maiores campanhas
22 =
23 = Rabaixados
24 = Promovidos
25 = Mais Rebaixados
26 = Mais Promovidos
27 = Evolução por Ano = uTorneios > uEvoClube
28 = Evolução por Torneio = uTorneios > uEvoClube
29 = Estados/Países
30 = Aproveitamento no Ano / Continentes = uTorneios > uAprovAno
31 = Aproveitamento no Ano / Torneio
32 = Fundação */