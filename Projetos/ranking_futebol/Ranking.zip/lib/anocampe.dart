import 'package:flutter/material.dart';
import 'package:ranking_futebol/unitglob.dart' as unitglob;
import 'package:ranking_futebol/FramePon.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class AnoCampePage extends StatefulWidget {
  const AnoCampePage({super.key});

  @override
  State<AnoCampePage> createState() => _AnoCampePageState();
}

class _AnoCampePageState extends State<AnoCampePage> {
  String itemInicio = '';
  List<String> listaAnos = [''];
  List listaDados = [];

  bool inLoading = false;

  retornarAnos() async {
    var url = Uri.parse('${unitglob.siteurl}15&p=${unitglob.concodigo}');
    inLoading = true;

    var response = await http.get(url);
    if (response.statusCode == 200) {
      List lista = await jsonDecode(response.body);
      if (lista.isNotEmpty) {
        for (var item in lista) {
          listaAnos.add(item['pon_ano'].toString());
          itemInicio = lista[lista.length - 1]['pon_ano'].toString();
        }
      }
    }
    retornarDados(itemInicio);
    setState(() {});
    inLoading = false;
  }

  retornarDados(String ano) async {
    var url = Uri.parse('${unitglob.siteurl}24&p=$ano;${unitglob.concodigo}');
    inLoading = true;

    var response = await http.get(url);
    if (response.statusCode == 200) {
      listaDados = await jsonDecode(response.body);
    }
    setState(() {});
    inLoading = false;
  }

  @override
  void initState() {
    super.initState();
    retornarAnos();
  }

  @override
  Widget build(BuildContext context) {
    return inLoading == false
        ? Scaffold(
            appBar: AppBar(title: Text(unitglob.tordescri)),
            body: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.only(left: 30, right: 30),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text(
                        'Campeões do Ano',
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 20,
                        ),
                      ),
                      DropdownButton<String>(
                        value: itemInicio,
                        icon: const Icon(Icons.arrow_drop_down),
                        elevation: 16,
                        style: const TextStyle(
                          color: Colors.deepPurple,
                          fontWeight: FontWeight.bold,
                          fontSize: 20,
                        ),
                        underline: Container(
                          height: 2,
                          color: Colors.deepPurpleAccent,
                        ),
                        onChanged: (String? value) {
                          setState(() {
                            itemInicio = value!;
                            retornarDados(itemInicio);
                          });
                        },
                        items: listaAnos
                            .map<DropdownMenuItem<String>>((String item) {
                          return DropdownMenuItem<String>(
                            value: item,
                            child: Text(item),
                          );
                        }).toList(),
                      ),
                    ],
                  ),
                ),

                Expanded(
                  child: ListView.builder(
                    itemCount: listaDados.isEmpty ? 0 : listaDados.length,
                    itemBuilder: (BuildContext context, int index) {
                      return PontosFrame(
                        item: listaDados[index],
                        funcao: (String texto) => clicou(texto),
                      );
                    },
                  ),
                ),
                //),
              ],
            ),
          )
        : Scaffold(
            body: Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: const [
                  CircularProgressIndicator(),
                  SizedBox(height: 15),
                  Text('Baixando dados...')
                ],
              ),
            ),
          );
  }

  clicou(String opcao) {
    if (unitglob.opcnum < 7) {
      switch (opcao) {
        case 'Pontos':
          {
            unitglob.opcnum = 1;
            unitglob.opcdesc = 'Pontuação';
            break;
          }
        case 'Gols':
          {
            unitglob.opcnum = 2;
            unitglob.opcdesc = 'Melhor Ataque';
            break;
          }
        case 'Saldo':
          {
            unitglob.opcnum = 3;
            unitglob.opcdesc = 'Saldo de Gols';
            break;
          }
        case 'Vitórias':
          {
            unitglob.opcnum = 4;
            unitglob.opcdesc = 'Mais Vitórias';
            break;
          }
        case 'Jogos':
          {
            unitglob.opcnum = 5;
            unitglob.opcdesc = 'Mais Jogos';
            break;
          }
        case 'Aprov':
          {
            unitglob.opcnum = 6;
            unitglob.opcdesc = 'Aproveitamento';
            break;
          }
      }
      setState(() {});
      retornarDados(itemInicio);
    }
  }
}
